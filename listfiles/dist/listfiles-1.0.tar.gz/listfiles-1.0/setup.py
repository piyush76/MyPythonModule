__author__ = 'piyush'
from distutils.core import setup

setup(

    name = 'listfiles',
    version = '1.0',
    py_modules = ['listfiles'],
    author = 'piyush',
    author_email = 'piyush_g@dell.com',
    description = 'A python module to list all the files which has changed in last 24 hour'

)






